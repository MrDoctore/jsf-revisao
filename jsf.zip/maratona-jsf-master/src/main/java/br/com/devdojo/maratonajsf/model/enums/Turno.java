package br.com.devdojo.maratonajsf.model.enums;

/**
 * Created by William on 3/9/2017.
 */
public enum Turno {
    MATUTINO, VESPERTINO, NOTURNO
}
