package bean;

import model.Student;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static java.util.Arrays.asList;

@RequestScoped
@Named
public class StudentBean implements Serializable {
   private Student student = new Student();
    private String[] namesArray = {"name1", "name2", "name3"};
    private List<String> namesArray2 = asList("name4", "name5", "name6");
    private Set<String> namesArray3 = new HashSet<>(asList("name7", "name8", "name9"));



    public String executar(String texto){
       return "Nome do aluno: " + texto;
    }

    public Student getStudent() {
        return student;
    }


    public Set<String> getNamesArray3() {
        return namesArray3;
    }

    public void setNamesArray3(Set<String> namesArray3) {
        this.namesArray3 = namesArray3;
    }

    public List<String> getNamesArray2() {
        return namesArray2;
    }

    public void setNamesArray2(List<String> namesArray2) {
        this.namesArray2 = namesArray2;
    }

    public String[] getNamesArray() {
        return namesArray;
    }

    public void setNamesArray(String[] namesArray) {
        this.namesArray = namesArray;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
