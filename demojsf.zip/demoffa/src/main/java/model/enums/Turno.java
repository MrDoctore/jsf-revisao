package model.enums;

public enum Turno {
    MATUTINO, VESPERTINO, NOTURNO
}
